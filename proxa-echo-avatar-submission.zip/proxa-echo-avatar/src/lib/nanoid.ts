/** Lightweight nanoid-compatible ID generator */
export function nanoid(length = 12): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
  let result = ''
  const arr = new Uint8Array(length)
  crypto.getRandomValues(arr)
  arr.forEach((b) => (result += chars[b % chars.length]))
  return result
}
