import type { ConversationMessage, AvatarEmotion } from '@/types'
import { buildSystemPrompt, getPersonaById } from './personas'

export interface StreamCallbacks {
  onTextChunk: (chunk: string) => void
  onEmotionUpdate: (emotion: AvatarEmotion) => void
  onComplete: (fullText: string) => void
  onError: (err: Error) => void
}

/**
 * Detects likely avatar emotion from response text using heuristics.
 * In production, this could be a dedicated classifier call.
 */
function detectEmotion(text: string): AvatarEmotion {
  const lower = text.toLowerCase()

  const skepticalTerms = ['however', "i'm not convinced", 'evidence', 'data', 'study', 'concern', 'not sure', 'doubt', 'skeptic', 'question']
  const positiveTerms = ['interesting', 'impressive', 'excellent', 'great', 'good point', 'appreciate', 'helpful', 'thank']
  const engagedTerms = ['tell me more', 'how does', 'what about', 'can you explain', 'elaborate', 'specifically']
  const concernedTerms = ['worry', 'concern', 'risk', 'adverse', 'side effect', 'safety', 'contraindic']

  const score = (terms: string[]) => terms.filter((t) => lower.includes(t)).length

  const scores = {
    skeptical: score(skepticalTerms),
    positive: score(positiveTerms),
    engaged: score(engagedTerms),
    concerned: score(concernedTerms),
  }

  const max = Math.max(...Object.values(scores))
  if (max === 0) return 'neutral'
  const winner = Object.entries(scores).find(([, v]) => v === max)![0]
  return winner as AvatarEmotion
}

/**
 * Streams a Claude response for the given conversation history.
 * Uses the Anthropic API directly from the browser (requires ANTHROPIC_API_KEY env var).
 *
 * NOTE: In production, route through your backend proxy to keep the API key server-side.
 */
export async function streamAvatarResponse(
  personaId: string,
  messages: ConversationMessage[],
  productContext: string | undefined,
  callbacks: StreamCallbacks
): Promise<void> {
  const persona = getPersonaById(personaId)
  if (!persona) {
    callbacks.onError(new Error(`Unknown persona: ${personaId}`))
    return
  }

  const systemPrompt = buildSystemPrompt(persona, productContext)

  // Convert to Anthropic message format
  const apiMessages = messages.map((m) => ({
    role: m.role as 'user' | 'assistant',
    content: m.content,
  }))

  const ANTHROPIC_API_KEY = import.meta.env.VITE_ANTHROPIC_API_KEY

  if (!ANTHROPIC_API_KEY) {
    // Demo mode: simulate a response
    await simulateResponse(persona.name, messages, callbacks)
    return
  }

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-access': 'true',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 300,
        system: systemPrompt,
        messages: apiMessages,
        stream: true,
      }),
    })

    if (!response.ok) {
      const errBody = await response.text()
      throw new Error(`Anthropic API error ${response.status}: ${errBody}`)
    }

    const reader = response.body!.getReader()
    const decoder = new TextDecoder()
    let fullText = ''
    let buffer = ''

    while (true) {
      const { done, value } = await reader.read()
      if (done) break

      buffer += decoder.decode(value, { stream: true })
      const lines = buffer.split('\n')
      buffer = lines.pop() ?? ''

      for (const line of lines) {
        if (!line.startsWith('data: ')) continue
        const data = line.slice(6).trim()
        if (data === '[DONE]') continue

        try {
          const event = JSON.parse(data)
          if (event.type === 'content_block_delta' && event.delta?.type === 'text_delta') {
            const chunk = event.delta.text
            fullText += chunk
            callbacks.onTextChunk(chunk)

            // Update emotion at natural sentence breaks
            if (chunk.includes('.') || chunk.includes('?') || chunk.includes('!')) {
              callbacks.onEmotionUpdate(detectEmotion(fullText))
            }
          }
        } catch {
          // Malformed SSE chunk — skip
        }
      }
    }

    callbacks.onComplete(fullText)
  } catch (err) {
    callbacks.onError(err instanceof Error ? err : new Error(String(err)))
  }
}

/**
 * Demo mode simulation — used when no API key is configured.
 * Streams pre-written responses based on persona and turn count.
 */
async function simulateResponse(
  personaName: string,
  messages: ConversationMessage[],
  callbacks: StreamCallbacks
): Promise<void> {
  const turnCount = messages.filter((m) => m.role === 'assistant').length
  const lastUserMsg = messages.filter((m) => m.role === 'user').pop()?.content.toLowerCase() ?? ''

  const demos: Array<{ text: string; emotion: AvatarEmotion }> = [
    {
      text: `Hello, I only have about 10 minutes before my next patient. What specifically did you want to discuss today?`,
      emotion: 'neutral',
    },
    {
      text: `That's an interesting claim. What was the primary endpoint of that trial, and what was the patient population?`,
      emotion: 'engaged',
    },
    {
      text: `I've seen a lot of data like this before. The real question is how it performs against the current standard of care in a real-world setting.`,
      emotion: 'skeptical',
    },
    {
      text: `The safety profile you mentioned is actually better than I expected. What's the dosing regimen, and are there any contraindications I should be aware of?`,
      emotion: 'positive',
    },
    {
      text: `I do have concerns about the long-term data. Six months of follow-up is not sufficient for me to feel confident recommending this to my patients.`,
      emotion: 'concerned',
    },
    {
      text: `That's a fair point. Leave me the clinical summary and I'll review it when I have time. No promises, but you've given me something to think about.`,
      emotion: 'neutral',
    },
  ]

  const demo = demos[Math.min(turnCount, demos.length - 1)]

  // Emit emotion first
  callbacks.onEmotionUpdate(demo.emotion)

  // Stream word by word for realism
  const words = demo.text.split(' ')
  let fullText = ''

  for (const word of words) {
    await new Promise((r) => setTimeout(r, 60 + Math.random() * 80))
    const chunk = (fullText.length === 0 ? '' : ' ') + word
    fullText += chunk
    callbacks.onTextChunk(chunk)
  }

  callbacks.onComplete(fullText)
}
