import { create } from 'zustand'
import type { ConversationMessage, SessionState, AvatarEmotion, AvatarAnimState } from '@/types'
import { nanoid } from './nanoid'

interface SessionStore {
  // Session
  session: SessionState | null
  personaId: string
  productContext: string

  // Avatar animation state
  avatarAnim: AvatarAnimState

  // UI state
  isListening: boolean
  isSpeaking: boolean
  isThinking: boolean
  micLevel: number
  interimTranscript: string
  currentStreamText: string
  error: string | null

  // Actions
  initSession: (personaId: string, productContext?: string) => void
  endSession: () => void
  setPersonaId: (id: string) => void
  setProductContext: (ctx: string) => void

  addMessage: (role: 'user' | 'assistant', content: string, emotion?: AvatarEmotion) => ConversationMessage
  updateLastAssistantMessage: (content: string) => void

  setListening: (v: boolean) => void
  setSpeaking: (v: boolean) => void
  setThinking: (v: boolean) => void
  setMicLevel: (v: number) => void
  setInterimTranscript: (v: string) => void
  setCurrentStreamText: (v: string) => void
  appendStreamText: (chunk: string) => void
  clearStreamText: () => void

  updateAvatarAnim: (patch: Partial<AvatarAnimState>) => void
  setError: (msg: string | null) => void
}

const DEFAULT_ANIM: AvatarAnimState = {
  emotion: 'neutral',
  isSpeaking: false,
  mouthOpenness: 0,
  eyeBlink: false,
  headRotX: 0,
  headRotY: 0,
  browRaise: 0,
  gazeX: 0,
  gazeY: 0,
}

export const useSessionStore = create<SessionStore>((set, get) => ({
  session: null,
  personaId: 'dr-sarah-chen',
  productContext: '',
  avatarAnim: DEFAULT_ANIM,
  isListening: false,
  isSpeaking: false,
  isThinking: false,
  micLevel: 0,
  interimTranscript: '',
  currentStreamText: '',
  error: null,

  initSession: (personaId, productContext = '') => {
    set({
      session: {
        sessionId: nanoid(),
        personaId,
        messages: [],
        isActive: true,
        startedAt: Date.now(),
        totalTurns: 0,
      },
      personaId,
      productContext,
      avatarAnim: DEFAULT_ANIM,
      error: null,
    })
  },

  endSession: () => {
    set((state) => ({
      session: state.session
        ? { ...state.session, isActive: false }
        : null,
      isListening: false,
      isSpeaking: false,
      isThinking: false,
    }))
  },

  setPersonaId: (id) => set({ personaId: id }),
  setProductContext: (ctx) => set({ productContext: ctx }),

  addMessage: (role, content, emotion) => {
    const msg: ConversationMessage = {
      id: nanoid(),
      role,
      content,
      timestamp: Date.now(),
      emotion,
    }
    set((state) => ({
      session: state.session
        ? {
            ...state.session,
            messages: [...state.session.messages, msg],
            totalTurns: state.session.totalTurns + (role === 'user' ? 1 : 0),
          }
        : state.session,
    }))
    return msg
  },

  updateLastAssistantMessage: (content) => {
    set((state) => {
      if (!state.session) return state
      const messages = [...state.session.messages]
      const lastIdx = messages.length - 1
      if (lastIdx >= 0 && messages[lastIdx].role === 'assistant') {
        messages[lastIdx] = { ...messages[lastIdx], content }
      }
      return { session: { ...state.session, messages } }
    })
  },

  setListening: (v) => set({ isListening: v }),
  setSpeaking: (v) => set({ isSpeaking: v }),
  setThinking: (v) => set({ isThinking: v }),
  setMicLevel: (v) => set({ micLevel: v }),
  setInterimTranscript: (v) => set({ interimTranscript: v }),
  setCurrentStreamText: (v) => set({ currentStreamText: v }),
  appendStreamText: (chunk) =>
    set((s) => ({ currentStreamText: s.currentStreamText + chunk })),
  clearStreamText: () => set({ currentStreamText: '' }),

  updateAvatarAnim: (patch) =>
    set((s) => ({ avatarAnim: { ...s.avatarAnim, ...patch } })),

  setError: (msg) => set({ error: msg }),
}))
