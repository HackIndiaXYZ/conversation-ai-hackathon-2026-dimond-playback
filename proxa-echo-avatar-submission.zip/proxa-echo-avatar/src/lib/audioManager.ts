/**
 * AudioManager
 * Handles microphone capture, speech-to-text via Web Speech API,
 * and browser TTS with phoneme extraction for lip sync.
 */

export type TranscriptCallback = (text: string, isFinal: boolean) => void
export type AudioLevelCallback = (level: number) => void

export class AudioManager {
  private recognition: SpeechRecognition | null = null
  private audioContext: AudioContext | null = null
  private analyser: AnalyserNode | null = null
  private micStream: MediaStream | null = null
  private levelAnimFrame: number | null = null
  private synthesis: SpeechSynthesis = window.speechSynthesis
  private currentUtterance: SpeechSynthesisUtterance | null = null

  // ── Speech Recognition ───────────────────────────────────────

  async startListening(
    onTranscript: TranscriptCallback,
    onLevel?: AudioLevelCallback
  ): Promise<void> {
    const SpeechRecognitionAPI =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition

    if (!SpeechRecognitionAPI) {
      throw new Error('Speech recognition not supported in this browser.')
    }

    this.recognition = new SpeechRecognitionAPI()
    this.recognition.continuous = true
    this.recognition.interimResults = true
    this.recognition.lang = 'en-US'
    this.recognition.maxAlternatives = 1

    this.recognition.onresult = (event: SpeechRecognitionEvent) => {
      let interimText = ''
      let finalText = ''

      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript
        if (event.results[i].isFinal) {
          finalText += transcript
        } else {
          interimText += transcript
        }
      }

      if (finalText) {
        onTranscript(finalText.trim(), true)
      } else if (interimText) {
        onTranscript(interimText.trim(), false)
      }
    }

    this.recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
      if (event.error === 'no-speech') return // ignore silence
      console.error('Speech recognition error:', event.error)
    }

    this.recognition.start()

    // Start microphone level monitoring
    if (onLevel) {
      await this.startLevelMonitor(onLevel)
    }
  }

  stopListening(): void {
    this.recognition?.stop()
    this.recognition = null
    this.stopLevelMonitor()
  }

  // ── Microphone Level ─────────────────────────────────────────

  private async startLevelMonitor(onLevel: AudioLevelCallback): Promise<void> {
    try {
      this.micStream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false })
      this.audioContext = new AudioContext()
      const source = this.audioContext.createMediaStreamSource(this.micStream)
      this.analyser = this.audioContext.createAnalyser()
      this.analyser.fftSize = 256
      source.connect(this.analyser)

      const dataArray = new Uint8Array(this.analyser.frequencyBinCount)

      const tick = () => {
        if (!this.analyser) return
        this.analyser.getByteFrequencyData(dataArray)
        const avg = dataArray.reduce((a, b) => a + b, 0) / dataArray.length
        onLevel(Math.min(1, avg / 128))
        this.levelAnimFrame = requestAnimationFrame(tick)
      }
      tick()
    } catch (err) {
      console.warn('Could not access microphone for level monitoring:', err)
    }
  }

  private stopLevelMonitor(): void {
    if (this.levelAnimFrame) {
      cancelAnimationFrame(this.levelAnimFrame)
      this.levelAnimFrame = null
    }
    this.micStream?.getTracks().forEach((t) => t.stop())
    this.micStream = null
    this.audioContext?.close()
    this.audioContext = null
    this.analyser = null
  }

  // ── Text-to-Speech ───────────────────────────────────────────

  speak(
    text: string,
    voiceConfig: { rate?: number; pitch?: number; volume?: number } = {},
    onBoundary?: (charIndex: number) => void,
    onEnd?: () => void
  ): void {
    // Cancel any in-flight speech
    this.stopSpeaking()

    const utterance = new SpeechSynthesisUtterance(text)
    utterance.rate = voiceConfig.rate ?? 0.95
    utterance.pitch = voiceConfig.pitch ?? 1.0
    utterance.volume = voiceConfig.volume ?? 1.0

    // Prefer a higher-quality voice if available
    const voices = this.synthesis.getVoices()
    const preferred = voices.find(
      (v) => v.lang === 'en-US' && (v.name.includes('Natural') || v.name.includes('Neural'))
    ) || voices.find((v) => v.lang === 'en-US')
    if (preferred) utterance.voice = preferred

    if (onBoundary) {
      utterance.addEventListener('boundary', (e: SpeechSynthesisEvent) => {
        onBoundary(e.charIndex)
      })
    }

    utterance.onend = () => {
      this.currentUtterance = null
      onEnd?.()
    }

    this.currentUtterance = utterance
    this.synthesis.speak(utterance)
  }

  stopSpeaking(): void {
    this.synthesis.cancel()
    this.currentUtterance = null
  }

  get isSpeaking(): boolean {
    return this.synthesis.speaking
  }

  // ── Phoneme Approximation ────────────────────────────────────
  /**
   * Approximates mouth openness from text content.
   * A real implementation would use Rhubarb or Allosaurus.
   * This lightweight version analyzes vowel density in words.
   */
  estimatePhonemes(text: string, durationMs: number): Array<{ t: number; openness: number }> {
    const words = text.split(/\s+/)
    const msPerWord = durationMs / Math.max(words.length, 1)
    const frames: Array<{ t: number; openness: number }> = []

    words.forEach((word, wi) => {
      const t = wi * msPerWord
      const vowelCount = (word.match(/[aeiouAEIOU]/g) || []).length
      const vowelRatio = vowelCount / Math.max(word.length, 1)

      // Add 3 keyframes per word: ramp up, peak, ramp down
      frames.push({ t, openness: 0 })
      frames.push({ t: t + msPerWord * 0.3, openness: 0.3 + vowelRatio * 0.5 })
      frames.push({ t: t + msPerWord * 0.6, openness: 0.2 + vowelRatio * 0.4 })
      frames.push({ t: t + msPerWord * 0.9, openness: 0.05 })
    })

    return frames
  }

  destroy(): void {
    this.stopListening()
    this.stopSpeaking()
  }
}
