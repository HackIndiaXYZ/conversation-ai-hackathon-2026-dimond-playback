import React, { useRef, useEffect } from 'react'
import type { AvatarAnimState, AvatarEmotion } from '@/types'
import type { AvatarAppearance } from '@/types'

interface AvatarSVGProps {
  appearance: AvatarAppearance
  animState: AvatarAnimState
  size?: number
}

/**
 * SVGAvatar
 *
 * A procedurally-animated SVG avatar with:
 * - Real-time lip sync (mouthOpenness 0–1)
 * - Eye blink animation
 * - Head rotation (CSS transform)
 * - Emotion-driven eyebrow and expression changes
 * - 5 visual variants (male/female with different appearances)
 */
export const SVGAvatar: React.FC<AvatarSVGProps> = ({ appearance, animState, size = 320 }) => {
  const containerRef = useRef<HTMLDivElement>(null)

  // Apply head rotation via CSS transform for performance
  useEffect(() => {
    if (!containerRef.current) return
    const rotX = Math.max(-10, Math.min(10, animState.headRotX))
    const rotY = Math.max(-15, Math.min(15, animState.headRotY))
    containerRef.current.style.transform = `rotateX(${rotX}deg) rotateY(${rotY}deg)`
  }, [animState.headRotX, animState.headRotY])

  const { svgVariant, skinTone, hairColor, attire } = appearance
  const isFemale = svgVariant.startsWith('female')
  const emotionColor = getEmotionColor(animState.emotion)

  // Mouth shape based on openness
  const mouth = getMouthPath(animState.mouthOpenness, animState.isSpeaking)

  // Eyebrow raise / furrow
  const browOffset = animState.browRaise * 8

  // Eye shape based on blink
  const eyeRY = animState.eyeBlink ? 0.5 : 11

  // Gaze offset
  const gazeXOffset = animState.gazeX * 4
  const gazeYOffset = animState.gazeY * 3

  const cx = size / 2
  const headTop = size * 0.08
  const headH = size * 0.55
  const faceY = headTop + headH * 0.1

  return (
    <div
      ref={containerRef}
      style={{
        width: size,
        height: size,
        transformStyle: 'preserve-3d',
        transition: 'transform 0.1s ease-out',
        willChange: 'transform',
      }}
    >
      <svg
        viewBox={`0 0 ${size} ${size}`}
        width={size}
        height={size}
        xmlns="http://www.w3.org/2000/svg"
        style={{ display: 'block' }}
      >
        <defs>
          {/* Skin gradient for depth */}
          <radialGradient id="skinGrad" cx="50%" cy="40%" r="60%">
            <stop offset="0%" stopColor={lighten(skinTone, 20)} />
            <stop offset="100%" stopColor={darken(skinTone, 10)} />
          </radialGradient>

          {/* Hair gradient */}
          <radialGradient id="hairGrad" cx="50%" cy="30%" r="70%">
            <stop offset="0%" stopColor={lighten(hairColor, 25)} />
            <stop offset="100%" stopColor={hairColor} />
          </radialGradient>

          {/* Emotion glow filter */}
          <filter id="emotionGlow">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>

          {/* Clip for face */}
          <clipPath id="faceClip">
            <ellipse cx={cx} cy={faceY + headH * 0.45} rx={headH * 0.38} ry={headH * 0.48} />
          </clipPath>
        </defs>

        {/* ── Shoulders / Body ── */}
        <ShoulderShape size={size} cx={cx} attire={attire} />

        {/* ── Neck ── */}
        <ellipse
          cx={cx}
          cy={size * 0.68}
          rx={size * 0.06}
          ry={size * 0.07}
          fill="url(#skinGrad)"
        />

        {/* ── Head ── */}
        <ellipse
          cx={cx}
          cy={faceY + headH * 0.45}
          rx={headH * 0.38}
          ry={headH * 0.48}
          fill="url(#skinGrad)"
          stroke={darken(skinTone, 15)}
          strokeWidth="0.5"
        />

        {/* ── Hair ── */}
        <HairShape
          svgVariant={svgVariant}
          cx={cx}
          headTop={headTop}
          headH={headH}
          hairGrad="url(#hairGrad)"
          size={size}
        />

        {/* ── Ears ── */}
        <ellipse
          cx={cx - headH * 0.38}
          cy={faceY + headH * 0.42}
          rx={headH * 0.055}
          ry={headH * 0.09}
          fill="url(#skinGrad)"
        />
        <ellipse
          cx={cx + headH * 0.38}
          cy={faceY + headH * 0.42}
          rx={headH * 0.055}
          ry={headH * 0.09}
          fill="url(#skinGrad)"
        />

        {/* ── Eyebrows ── */}
        <g strokeLinecap="round" strokeWidth="2.5">
          {/* Left eyebrow */}
          <path
            d={`M ${cx - headH * 0.22} ${faceY + headH * 0.22 - browOffset} Q ${cx - headH * 0.11} ${faceY + headH * 0.19 - browOffset - 3} ${cx - headH * 0.01} ${faceY + headH * 0.22 - browOffset}`}
            stroke={darken(hairColor, 5)}
            fill="none"
          />
          {/* Right eyebrow */}
          <path
            d={`M ${cx + headH * 0.01} ${faceY + headH * 0.22 - browOffset} Q ${cx + headH * 0.11} ${faceY + headH * 0.19 - browOffset - 3} ${cx + headH * 0.22} ${faceY + headH * 0.22 - browOffset}`}
            stroke={darken(hairColor, 5)}
            fill="none"
          />
        </g>

        {/* ── Eyes ── */}
        <g>
          {/* Left eye white */}
          <ellipse
            cx={cx - headH * 0.11 + gazeXOffset}
            cy={faceY + headH * 0.32 + gazeYOffset}
            rx={headH * 0.09}
            ry={eyeRY}
            fill="white"
          />
          {/* Left iris */}
          <ellipse
            cx={cx - headH * 0.11 + gazeXOffset}
            cy={faceY + headH * 0.32 + gazeYOffset}
            rx={headH * 0.055}
            ry={Math.min(eyeRY - 1, headH * 0.065)}
            fill={isFemale ? '#3E6FA3' : '#2C5F2E'}
          />
          {/* Left pupil */}
          <circle
            cx={cx - headH * 0.11 + gazeXOffset}
            cy={faceY + headH * 0.32 + gazeYOffset}
            r={headH * 0.028}
            fill="#111"
          />
          {/* Left highlight */}
          <circle
            cx={cx - headH * 0.09 + gazeXOffset}
            cy={faceY + headH * 0.30 + gazeYOffset}
            r={headH * 0.012}
            fill="white"
            opacity="0.9"
          />
          {/* Left eyelid (blink) */}
          {animState.eyeBlink && (
            <ellipse
              cx={cx - headH * 0.11 + gazeXOffset}
              cy={faceY + headH * 0.32}
              rx={headH * 0.09}
              ry={headH * 0.028}
              fill={darken(skinTone, 5)}
            />
          )}

          {/* Right eye white */}
          <ellipse
            cx={cx + headH * 0.11 + gazeXOffset}
            cy={faceY + headH * 0.32 + gazeYOffset}
            rx={headH * 0.09}
            ry={eyeRY}
            fill="white"
          />
          {/* Right iris */}
          <ellipse
            cx={cx + headH * 0.11 + gazeXOffset}
            cy={faceY + headH * 0.32 + gazeYOffset}
            rx={headH * 0.055}
            ry={Math.min(eyeRY - 1, headH * 0.065)}
            fill={isFemale ? '#3E6FA3' : '#2C5F2E'}
          />
          {/* Right pupil */}
          <circle
            cx={cx + headH * 0.11 + gazeXOffset}
            cy={faceY + headH * 0.32 + gazeYOffset}
            r={headH * 0.028}
            fill="#111"
          />
          {/* Right highlight */}
          <circle
            cx={cx + headH * 0.13 + gazeXOffset}
            cy={faceY + headH * 0.30 + gazeYOffset}
            r={headH * 0.012}
            fill="white"
            opacity="0.9"
          />
          {animState.eyeBlink && (
            <ellipse
              cx={cx + headH * 0.11 + gazeXOffset}
              cy={faceY + headH * 0.32}
              rx={headH * 0.09}
              ry={headH * 0.028}
              fill={darken(skinTone, 5)}
            />
          )}
        </g>

        {/* ── Nose ── */}
        <path
          d={`M ${cx} ${faceY + headH * 0.42} 
              Q ${cx - headH * 0.04} ${faceY + headH * 0.52} ${cx - headH * 0.07} ${faceY + headH * 0.54}
              M ${cx} ${faceY + headH * 0.42}
              Q ${cx + headH * 0.04} ${faceY + headH * 0.52} ${cx + headH * 0.07} ${faceY + headH * 0.54}`}
          stroke={darken(skinTone, 18)}
          strokeWidth="1.5"
          fill="none"
          strokeLinecap="round"
        />

        {/* ── Mouth ── */}
        <g>
          {/* Mouth opening */}
          {animState.mouthOpenness > 0.05 && (
            <ellipse
              cx={cx}
              cy={faceY + headH * 0.65}
              rx={headH * 0.09}
              ry={headH * 0.045 * animState.mouthOpenness}
              fill="#3A1A1A"
            />
          )}
          {/* Upper lip */}
          <path
            d={mouth.upper}
            fill={darken(skinTone, 15)}
            stroke="none"
          />
          {/* Lower lip */}
          <path
            d={mouth.lower}
            fill={darken(skinTone, 8)}
            stroke="none"
          />
          {/* Mouth line */}
          <path
            d={mouth.line}
            stroke={darken(skinTone, 25)}
            strokeWidth="1.2"
            fill="none"
            strokeLinecap="round"
          />
        </g>

        {/* ── Emotion indicator ring (subtle) ── */}
        <circle
          cx={cx}
          cy={faceY + headH * 0.45}
          r={headH * 0.48 + 4}
          fill="none"
          stroke={emotionColor}
          strokeWidth="2"
          opacity="0.3"
          style={{ transition: 'stroke 0.5s ease, opacity 0.5s ease' }}
        />

        {/* ── Speaking pulse ── */}
        {animState.isSpeaking && (
          <circle
            cx={cx}
            cy={faceY + headH * 0.45}
            r={headH * 0.48 + 8}
            fill="none"
            stroke={emotionColor}
            strokeWidth="1.5"
            opacity="0.2"
          >
            <animate attributeName="r" values={`${headH * 0.48 + 4};${headH * 0.48 + 14};${headH * 0.48 + 4}`} dur="1.5s" repeatCount="indefinite" />
            <animate attributeName="opacity" values="0.3;0;0.3" dur="1.5s" repeatCount="indefinite" />
          </circle>
        )}
      </svg>
    </div>
  )
}

// ─────────────────────────────────────────────
// Sub-components
// ─────────────────────────────────────────────

const ShoulderShape: React.FC<{ size: number; cx: number; attire: string }> = ({ size, cx, attire }) => {
  const colors: Record<string, string> = {
    whitecoat: '#F8F8FF',
    business: '#1E3A5F',
    scrubs: '#4A90A4',
  }
  const color = colors[attire] ?? colors.whitecoat

  return (
    <g>
      {/* Body */}
      <path
        d={`M ${cx - size * 0.38} ${size} Q ${cx - size * 0.32} ${size * 0.72} ${cx} ${size * 0.72} Q ${cx + size * 0.32} ${size * 0.72} ${cx + size * 0.38} ${size} Z`}
        fill={color}
      />
      {/* Collar / lapels */}
      {attire === 'whitecoat' && (
        <path
          d={`M ${cx - size * 0.08} ${size * 0.72} L ${cx - size * 0.04} ${size * 0.78} L ${cx} ${size * 0.76} L ${cx + size * 0.04} ${size * 0.78} L ${cx + size * 0.08} ${size * 0.72}`}
          fill="#E8E8E8"
          stroke="#CCC"
          strokeWidth="0.5"
        />
      )}
    </g>
  )
}

const HairShape: React.FC<{
  svgVariant: string
  cx: number
  headTop: number
  headH: number
  hairGrad: string
  size: number
}> = ({ svgVariant, cx, headTop, headH, hairGrad, size }) => {
  if (svgVariant === 'male-2') {
    // Bald / very short
    return (
      <ellipse
        cx={cx}
        cy={headTop + headH * 0.15}
        rx={headH * 0.36}
        ry={headH * 0.18}
        fill={hairGrad}
        opacity="0.4"
      />
    )
  }

  if (svgVariant === 'female-3') {
    // Medium length
    return (
      <g>
        <ellipse cx={cx} cy={headTop + headH * 0.12} rx={headH * 0.39} ry={headH * 0.22} fill={hairGrad} />
        <path
          d={`M ${cx - headH * 0.38} ${headTop + headH * 0.35} Q ${cx - headH * 0.42} ${headTop + headH * 0.7} ${cx - headH * 0.36} ${headTop + headH * 0.85}`}
          stroke={hairGrad}
          strokeWidth={headH * 0.08}
          fill="none"
          strokeLinecap="round"
        />
        <path
          d={`M ${cx + headH * 0.38} ${headTop + headH * 0.35} Q ${cx + headH * 0.42} ${headTop + headH * 0.7} ${cx + headH * 0.36} ${headTop + headH * 0.85}`}
          stroke={hairGrad}
          strokeWidth={headH * 0.08}
          fill="none"
          strokeLinecap="round"
        />
      </g>
    )
  }

  if (svgVariant === 'female-1') {
    // Bun
    return (
      <g>
        <ellipse cx={cx} cy={headTop + headH * 0.1} rx={headH * 0.37} ry={headH * 0.2} fill={hairGrad} />
        <circle cx={cx} cy={headTop - headH * 0.02} r={headH * 0.12} fill={hairGrad} />
      </g>
    )
  }

  if (svgVariant === 'female-2') {
    // Long
    return (
      <g>
        <ellipse cx={cx} cy={headTop + headH * 0.1} rx={headH * 0.39} ry={headH * 0.2} fill={hairGrad} />
        <path
          d={`M ${cx - headH * 0.38} ${headTop + headH * 0.3} Q ${cx - headH * 0.44} ${headTop + headH * 0.9} ${cx - headH * 0.3} ${size * 0.78}`}
          stroke={hairGrad}
          strokeWidth={headH * 0.1}
          fill="none"
          strokeLinecap="round"
        />
        <path
          d={`M ${cx + headH * 0.38} ${headTop + headH * 0.3} Q ${cx + headH * 0.44} ${headTop + headH * 0.9} ${cx + headH * 0.3} ${size * 0.78}`}
          stroke={hairGrad}
          strokeWidth={headH * 0.1}
          fill="none"
          strokeLinecap="round"
        />
      </g>
    )
  }

  // male-1: short hair
  return (
    <ellipse
      cx={cx}
      cy={headTop + headH * 0.12}
      rx={headH * 0.37}
      ry={headH * 0.2}
      fill={hairGrad}
    />
  )
}

// ─────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────

function getMouthPath(openness: number, isSpeaking: boolean) {
  // Mouth positions shift when speaking
  const lift = isSpeaking ? openness * 2 : 0

  // These values assume a 320×320 viewBox centered avatar
  // They'll scale correctly since we use headH-relative positioning above
  // For now, return path strings relative to center (cx=160, faceY+headH*0.63)
  return {
    upper: `M 136 ${178 - lift} Q 160 ${175 - lift - openness * 3} 184 ${178 - lift} Q 160 ${183 - lift} 136 ${178 - lift} Z`,
    lower: `M 136 ${178} Q 160 ${186 + openness * 8} 184 ${178} Q 160 ${182} 136 ${178} Z`,
    line: `M 136 ${178} Q 160 ${178 + openness * 4} 184 ${178}`,
  }
}

function getEmotionColor(emotion: AvatarEmotion): string {
  const colors: Record<AvatarEmotion, string> = {
    neutral: '#888787',
    engaged: '#378ADD',
    skeptical: '#D85A30',
    positive: '#3B6D11',
    thinking: '#7F77DD',
    concerned: '#BA7517',
  }
  return colors[emotion] ?? colors.neutral
}

function lighten(hex: string, amount: number): string {
  return adjustHex(hex, amount)
}

function darken(hex: string, amount: number): string {
  return adjustHex(hex, -amount)
}

function adjustHex(hex: string, amount: number): string {
  const num = parseInt(hex.replace('#', ''), 16)
  const r = Math.min(255, Math.max(0, (num >> 16) + amount))
  const g = Math.min(255, Math.max(0, ((num >> 8) & 0xff) + amount))
  const b = Math.min(255, Math.max(0, (num & 0xff) + amount))
  return `#${((r << 16) | (g << 8) | b).toString(16).padStart(6, '0')}`
}
