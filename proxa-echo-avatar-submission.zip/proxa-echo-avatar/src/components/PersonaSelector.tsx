import React from 'react'
import { HCP_PERSONAS } from '@/lib/personas'
import { useSessionStore } from '@/lib/sessionStore'

interface PersonaSelectorProps {
  onStart: () => void
}

export const PersonaSelector: React.FC<PersonaSelectorProps> = ({ onStart }) => {
  const { personaId, setPersonaId, productContext, setProductContext } = useSessionStore()

  return (
    <div className="persona-selector">
      <div className="selector-header">
        <div className="logo">
          <span className="logo-mark">P</span>
          <span className="logo-text">Proxa <em>Echo</em></span>
        </div>
        <p className="tagline">AI-powered HCP roleplay for pharmaceutical sales training</p>
      </div>

      <div className="selector-body">
        <section className="section">
          <h2 className="section-label">Select Physician</h2>
          <div className="persona-grid">
            {HCP_PERSONAS.map((persona) => (
              <button
                key={persona.id}
                className={`persona-card ${personaId === persona.id ? 'selected' : ''}`}
                onClick={() => setPersonaId(persona.id)}
              >
                <div
                  className="avatar-mini"
                  style={{ background: getAvatarColor(persona.appearance.svgVariant) }}
                >
                  <span>{getInitials(persona.name)}</span>
                </div>
                <div className="persona-info">
                  <div className="persona-name">{persona.name}</div>
                  <div className="persona-title">{persona.title}</div>
                  <div className="persona-specialty">{persona.specialty}</div>
                </div>
                <div className="trait-bars">
                  <TraitBar label="Skepticism" value={persona.traits.skepticism} color="var(--coral)" />
                  <TraitBar label="Warmth" value={persona.traits.warmth} color="var(--teal)" />
                  <TraitBar label="Curiosity" value={persona.traits.curiosity} color="var(--blue)" />
                </div>
                {personaId === persona.id && (
                  <div className="selected-badge">Selected</div>
                )}
              </button>
            ))}
          </div>
        </section>

        <section className="section">
          <h2 className="section-label">Product Context <span className="optional">(optional)</span></h2>
          <textarea
            className="product-input"
            value={productContext}
            onChange={(e) => setProductContext(e.target.value)}
            placeholder="Describe the drug / therapy being discussed. E.g. 'NEXVARA (vanzatinib) — a first-in-class ALK inhibitor for NSCLC with 68% ORR in ALPINE-2...'"
            rows={3}
          />
        </section>

        <button className="start-btn" onClick={onStart}>
          <span>Begin Simulation</span>
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
            <path d="M3 8h10M9 4l4 4-4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </button>
      </div>
    </div>
  )
}

const TraitBar: React.FC<{ label: string; value: number; color: string }> = ({ label, value, color }) => (
  <div className="trait-row">
    <span className="trait-label">{label}</span>
    <div className="trait-track">
      <div className="trait-fill" style={{ width: `${value * 100}%`, background: color }} />
    </div>
  </div>
)

function getInitials(name: string): string {
  return name.replace('Dr. ', '').split(' ').map((w) => w[0]).join('').slice(0, 2).toUpperCase()
}

function getAvatarColor(variant: string): string {
  const colors: Record<string, string> = {
    'female-1': 'linear-gradient(135deg, #7F77DD 0%, #534AB7 100%)',
    'female-2': 'linear-gradient(135deg, #1D9E75 0%, #0F6E56 100%)',
    'female-3': 'linear-gradient(135deg, #D85A30 0%, #993C1D 100%)',
    'male-1':   'linear-gradient(135deg, #378ADD 0%, #185FA5 100%)',
    'male-2':   'linear-gradient(135deg, #888780 0%, #5F5E5A 100%)',
  }
  return colors[variant] ?? colors['male-1']
}
