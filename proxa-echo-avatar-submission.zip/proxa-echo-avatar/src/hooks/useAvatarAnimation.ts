import { useEffect, useRef, useCallback } from 'react'
import { useSessionStore } from '@/lib/sessionStore'
import type { AvatarEmotion } from '@/types'

/**
 * useAvatarAnimation
 *
 * Drives the avatar's real-time animation state:
 * - Idle breathing / head sway
 * - Eye blink rhythm
 * - Lip sync from phoneme data
 * - Emotion-driven expressions
 */
export function useAvatarAnimation() {
  const updateAnim = useSessionStore((s) => s.updateAvatarAnim)
  const isSpeaking = useSessionStore((s) => s.isSpeaking)

  const idleFrameRef = useRef<number>(0)
  const lipSyncFrameRef = useRef<number>(0)
  const phonemesRef = useRef<Array<{ t: number; openness: number }>>([])
  const speakStartRef = useRef<number>(0)

  // ── Idle Animation Loop ──────────────────────────────────────
  useEffect(() => {
    let frame = 0

    const tick = () => {
      frame++
      const t = frame / 60 // time in seconds at ~60fps

      // Slow head bob
      const headRotX = Math.sin(t * 0.4) * 1.5
      const headRotY = Math.sin(t * 0.25) * 3

      // Gaze wander
      const gazeX = Math.sin(t * 0.3) * 0.15
      const gazeY = Math.sin(t * 0.2) * 0.1

      // Blink every ~4s with a 150ms window
      const blinkPhase = (t % 4) / 4
      const eyeBlink = blinkPhase > 0.97

      updateAnim({ headRotX, headRotY, gazeX, gazeY, eyeBlink })
      idleFrameRef.current = requestAnimationFrame(tick)
    }

    idleFrameRef.current = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(idleFrameRef.current)
  }, [updateAnim])

  // ── Lip Sync Loop ─────────────────────────────────────────────
  useEffect(() => {
    if (!isSpeaking) {
      updateAnim({ mouthOpenness: 0, isSpeaking: false })
      cancelAnimationFrame(lipSyncFrameRef.current)
      return
    }

    updateAnim({ isSpeaking: true })

    const tick = () => {
      const elapsed = performance.now() - speakStartRef.current
      const phonemes = phonemesRef.current

      if (phonemes.length === 0) {
        // Fallback: simple oscillation while speaking
        const openness = 0.2 + Math.abs(Math.sin(elapsed * 0.008)) * 0.3
        updateAnim({ mouthOpenness: openness })
      } else {
        // Find current phoneme frame by time
        let openness = 0
        for (let i = 0; i < phonemes.length - 1; i++) {
          const curr = phonemes[i]
          const next = phonemes[i + 1]
          if (elapsed >= curr.t && elapsed < next.t) {
            const alpha = (elapsed - curr.t) / (next.t - curr.t)
            openness = curr.openness + alpha * (next.openness - curr.openness)
            break
          }
        }
        updateAnim({ mouthOpenness: Math.max(0, Math.min(1, openness)) })
      }

      lipSyncFrameRef.current = requestAnimationFrame(tick)
    }

    speakStartRef.current = performance.now()
    lipSyncFrameRef.current = requestAnimationFrame(tick)

    return () => cancelAnimationFrame(lipSyncFrameRef.current)
  }, [isSpeaking, updateAnim])

  // ── Public Controls ──────────────────────────────────────────

  const setPhonemes = useCallback(
    (frames: Array<{ t: number; openness: number }>) => {
      phonemesRef.current = frames
      speakStartRef.current = performance.now()
    },
    []
  )

  const applyEmotion = useCallback(
    (emotion: AvatarEmotion) => {
      const presets: Record<AvatarEmotion, { browRaise: number; headRotX: number }> = {
        neutral:   { browRaise: 0,    headRotX: 0    },
        engaged:   { browRaise: 0.3,  headRotX: -2   },
        skeptical: { browRaise: -0.1, headRotX: 2    },
        positive:  { browRaise: 0.4,  headRotX: -3   },
        thinking:  { browRaise: 0.2,  headRotX: 4    },
        concerned: { browRaise: 0.15, headRotX: 1    },
      }
      const preset = presets[emotion] ?? presets.neutral
      updateAnim({ emotion, ...preset })
    },
    [updateAnim]
  )

  return { setPhonemes, applyEmotion }
}
