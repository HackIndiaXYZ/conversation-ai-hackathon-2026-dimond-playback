import React, { useState, useRef, useEffect } from 'react'
import { SVGAvatar } from './SVGAvatar'
import { useSessionStore } from '@/lib/sessionStore'
import { useConversation } from '@/hooks/useConversation'
import { getPersonaById } from '@/lib/personas'
import type { AvatarEmotion } from '@/types'

interface SessionViewProps {
  onEnd: () => void
}

export const SessionView: React.FC<SessionViewProps> = ({ onEnd }) => {
  const store = useSessionStore()
  const conv = useConversation()
  const [textInput, setTextInput] = useState('')
  const [showTranscript, setShowTranscript] = useState(false)
  const transcriptRef = useRef<HTMLDivElement>(null)

  const persona = getPersonaById(store.personaId)
  const avatarAnim = store.avatarAnim

  // Auto-scroll transcript
  useEffect(() => {
    if (transcriptRef.current) {
      transcriptRef.current.scrollTop = transcriptRef.current.scrollHeight
    }
  }, [store.session?.messages.length])

  const handleSendText = () => {
    if (!textInput.trim()) return
    conv.sendTextMessage(textInput.trim())
    setTextInput('')
  }

  const handleEndSession = () => {
    conv.interruptSpeech()
    conv.stopListening()
    store.endSession()
    onEnd()
  }

  const statusLabel = getStatusLabel(store)
  const emotionLabel = getEmotionLabel(avatarAnim.emotion)

  if (!persona) return null

  return (
    <div className="session-view">
      {/* ── Left: Avatar Panel ── */}
      <div className="avatar-panel">
        <div className="persona-badge">
          <div className="persona-badge-name">{persona.name}</div>
          <div className="persona-badge-role">{persona.title} · {persona.specialty}</div>
          <div className="persona-badge-institution">{persona.institution}</div>
        </div>

        <div className="avatar-stage">
          <div className="avatar-bg" />
          <SVGAvatar
            appearance={persona.appearance}
            animState={avatarAnim}
            size={300}
          />

          {/* Emotion indicator */}
          <div className={`emotion-chip emotion-${avatarAnim.emotion}`}>
            <span className="emotion-dot" />
            {emotionLabel}
          </div>

          {/* Speaking wave */}
          {store.isSpeaking && (
            <div className="speaking-wave">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="wave-bar" style={{ animationDelay: `${i * 0.1}s` }} />
              ))}
            </div>
          )}

          {/* Thinking indicator */}
          {store.isThinking && (
            <div className="thinking-dots">
              <span /><span /><span />
            </div>
          )}
        </div>

        {/* Stream text display */}
        <div className="response-display">
          {store.isThinking && !store.currentStreamText ? (
            <span className="thinking-label">Thinking…</span>
          ) : (
            <p className="stream-text">{store.currentStreamText}</p>
          )}
        </div>
      </div>

      {/* ── Right: Controls Panel ── */}
      <div className="controls-panel">
        {/* Header */}
        <div className="controls-header">
          <div className="session-meta">
            <span className="turn-count">{store.session?.totalTurns ?? 0} turns</span>
            <span className="sep">·</span>
            <SessionTimer startedAt={store.session?.startedAt ?? Date.now()} />
          </div>
          <button className="end-btn" onClick={handleEndSession}>End Session</button>
        </div>

        {/* Status */}
        <div className={`status-bar status-${getStatusType(store)}`}>
          <span className="status-indicator" />
          <span className="status-text">{statusLabel}</span>
        </div>

        {/* Interim transcript */}
        {store.interimTranscript && (
          <div className="interim-transcript">
            <span className="interim-label">Hearing: </span>
            <span className="interim-text">"{store.interimTranscript}"</span>
          </div>
        )}

        {/* Mic level */}
        {store.isListening && (
          <div className="mic-meter">
            <div className="mic-icon">
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                <rect x="4" y="1" width="6" height="8" rx="3" fill="currentColor" />
                <path d="M2 7c0 2.76 2.24 5 5 5s5-2.24 5-5" stroke="currentColor" strokeWidth="1.2" fill="none" strokeLinecap="round" />
                <line x1="7" y1="12" x2="7" y2="14" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" />
              </svg>
            </div>
            <div className="mic-track">
              <div className="mic-fill" style={{ width: `${store.micLevel * 100}%` }} />
            </div>
          </div>
        )}

        {/* Primary voice button */}
        <div className="voice-controls">
          {!store.isListening ? (
            <button
              className={`mic-btn ${store.isSpeaking || store.isThinking ? 'disabled' : ''}`}
              onClick={conv.startListening}
              disabled={store.isSpeaking || store.isThinking}
            >
              <MicIcon />
              <span>Hold to Speak</span>
            </button>
          ) : (
            <button className="mic-btn listening" onClick={() => conv.stopListening()}>
              <MicIcon active />
              <span>Tap to Send</span>
            </button>
          )}

          {store.isSpeaking && (
            <button className="interrupt-btn" onClick={conv.interruptSpeech}>
              <StopIcon />
              <span>Interrupt</span>
            </button>
          )}
        </div>

        {/* Text input fallback */}
        <div className="text-input-row">
          <input
            type="text"
            className="text-input"
            value={textInput}
            onChange={(e) => setTextInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSendText()}
            placeholder="Or type your message…"
            disabled={store.isSpeaking || store.isListening || store.isThinking}
          />
          <button
            className="send-btn"
            onClick={handleSendText}
            disabled={!textInput.trim() || store.isSpeaking || store.isListening || store.isThinking}
          >
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <path d="M1 7h12M8 2l5 5-5 5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </button>
        </div>

        {/* Transcript toggle */}
        <button
          className="transcript-toggle"
          onClick={() => setShowTranscript(!showTranscript)}
        >
          {showTranscript ? 'Hide' : 'Show'} Transcript
        </button>

        {/* Transcript */}
        {showTranscript && (
          <div className="transcript-panel" ref={transcriptRef}>
            {(store.session?.messages ?? []).length === 0 ? (
              <p className="transcript-empty">No messages yet. Start speaking to begin.</p>
            ) : (
              (store.session?.messages ?? []).map((msg) => (
                <div key={msg.id} className={`transcript-msg ${msg.role}`}>
                  <div className="msg-label">
                    {msg.role === 'user' ? 'You' : persona.name.split(' ')[1]}
                  </div>
                  <div className="msg-text">{msg.content}</div>
                </div>
              ))
            )}
          </div>
        )}

        {/* Error */}
        {store.error && (
          <div className="error-banner">
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
              <circle cx="7" cy="7" r="6" stroke="currentColor" strokeWidth="1.2" />
              <line x1="7" y1="4" x2="7" y2="7.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
              <circle cx="7" cy="10" r="0.8" fill="currentColor" />
            </svg>
            <span>{store.error}</span>
            <button onClick={() => store.setError(null)}>×</button>
          </div>
        )}
      </div>
    </div>
  )
}

// ─── Timer ─────────────────────────────────────────────────────────

const SessionTimer: React.FC<{ startedAt: number }> = ({ startedAt }) => {
  const [elapsed, setElapsed] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setElapsed(Math.floor((Date.now() - startedAt) / 1000))
    }, 1000)
    return () => clearInterval(interval)
  }, [startedAt])

  const mins = Math.floor(elapsed / 60).toString().padStart(2, '0')
  const secs = (elapsed % 60).toString().padStart(2, '0')
  return <span className="timer">{mins}:{secs}</span>
}

// ─── Icons ─────────────────────────────────────────────────────────

const MicIcon: React.FC<{ active?: boolean }> = ({ active }) => (
  <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
    <rect x="5.5" y="1" width="7" height="10" rx="3.5" fill={active ? '#EF4444' : 'currentColor'} />
    <path d="M2 9c0 3.866 3.134 7 7 7s7-3.134 7-7" stroke={active ? '#EF4444' : 'currentColor'} strokeWidth="1.5" fill="none" strokeLinecap="round" />
    <line x1="9" y1="16" x2="9" y2="18" stroke={active ? '#EF4444' : 'currentColor'} strokeWidth="1.5" strokeLinecap="round" />
  </svg>
)

const StopIcon: React.FC = () => (
  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
    <rect x="2" y="2" width="10" height="10" rx="2" fill="currentColor" />
  </svg>
)

// ─── Status helpers ─────────────────────────────────────────────────

function getStatusType(store: ReturnType<typeof useSessionStore.getState>): string {
  if (store.isListening) return 'listening'
  if (store.isThinking) return 'thinking'
  if (store.isSpeaking) return 'speaking'
  return 'idle'
}

function getStatusLabel(store: ReturnType<typeof useSessionStore.getState>): string {
  if (store.isListening) return 'Listening — speak now'
  if (store.isThinking) return 'Processing response…'
  if (store.isSpeaking) return `${getPersonaById(store.personaId)?.name.split(' ')[1] ?? 'Doctor'} is speaking`
  return 'Ready — tap the mic to respond'
}

function getEmotionLabel(emotion: AvatarEmotion): string {
  const labels: Record<AvatarEmotion, string> = {
    neutral: 'Neutral',
    engaged: 'Engaged',
    skeptical: 'Skeptical',
    positive: 'Positive',
    thinking: 'Thinking',
    concerned: 'Concerned',
  }
  return labels[emotion] ?? 'Neutral'
}
