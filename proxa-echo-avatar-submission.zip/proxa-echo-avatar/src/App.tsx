import React, { useState } from 'react'
import { PersonaSelector } from './components/PersonaSelector'
import { SessionView } from './components/SessionView'
import { useConversation } from './hooks/useConversation'
import './styles/global.css'

type AppView = 'setup' | 'session' | 'debrief'

export default function App() {
  const [view, setView] = useState<AppView>('setup')
  const conv = useConversation()

  const handleStart = () => {
    conv.startSession()
    setView('session')
  }

  const handleEnd = () => {
    setView('debrief')
  }

  const handleRestart = () => {
    setView('setup')
  }

  if (view === 'session') {
    return <SessionView onEnd={handleEnd} />
  }

  if (view === 'debrief') {
    return <DebriefView onRestart={handleRestart} />
  }

  return <PersonaSelector onStart={handleStart} />
}

const DebriefView: React.FC<{ onRestart: () => void }> = ({ onRestart }) => (
  <div className="debrief-view">
    <div className="debrief-card">
      <div className="debrief-icon">✓</div>
      <h1 className="debrief-title">Session Complete</h1>
      <p className="debrief-body">
        Your conversation has been recorded. Review your transcript and performance below.
      </p>
      <div className="debrief-actions">
        <button className="btn-primary" onClick={onRestart}>New Session</button>
      </div>
    </div>
  </div>
)
