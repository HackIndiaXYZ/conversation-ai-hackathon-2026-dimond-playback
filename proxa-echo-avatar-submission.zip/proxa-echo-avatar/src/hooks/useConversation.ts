import { useRef, useCallback, useEffect } from 'react'
import { useSessionStore } from '@/lib/sessionStore'
import { AudioManager } from '@/lib/audioManager'
import { streamAvatarResponse } from '@/lib/claudeClient'
import { useAvatarAnimation } from './useAvatarAnimation'

/**
 * useConversation
 *
 * Orchestrates the full voice→LLM→TTS→avatar pipeline:
 * 1. Mic input → Speech recognition → user message
 * 2. User message → Claude API (streaming) → assistant text
 * 3. Assistant text → Web Speech TTS → lip sync animation
 */
export function useConversation() {
  const store = useSessionStore()
  const { setPhonemes, applyEmotion } = useAvatarAnimation()
  const audioManagerRef = useRef<AudioManager>(new AudioManager())
  const pendingUserText = useRef('')

  useEffect(() => {
    const am = audioManagerRef.current
    return () => am.destroy()
  }, [])

  // ── Start Session ────────────────────────────────────────────

  const startSession = useCallback(() => {
    store.initSession(store.personaId, store.productContext)
  }, [store])

  // ── Voice Input ──────────────────────────────────────────────

  const startListening = useCallback(async () => {
    if (store.isSpeaking || store.isThinking) return

    store.setListening(true)
    store.setInterimTranscript('')

    try {
      await audioManagerRef.current.startListening(
        (text, isFinal) => {
          if (isFinal) {
            pendingUserText.current = text
            store.setInterimTranscript('')
            stopListeningAndRespond()
          } else {
            store.setInterimTranscript(text)
          }
        },
        (level) => store.setMicLevel(level)
      )
    } catch (err) {
      store.setError(err instanceof Error ? err.message : 'Microphone error')
      store.setListening(false)
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [store])

  const stopListeningAndRespond = useCallback(() => {
    audioManagerRef.current.stopListening()
    store.setListening(false)
    store.setMicLevel(0)

    const text = pendingUserText.current.trim()
    pendingUserText.current = ''

    if (!text || !store.session) return

    // Add user message
    store.addMessage('user', text)

    // Get LLM response
    handleLLMResponse(text)
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [store])

  const stopListening = useCallback(() => {
    audioManagerRef.current.stopListening()
    store.setListening(false)
    store.setMicLevel(0)
    store.setInterimTranscript('')
  }, [store])

  // ── LLM Response ─────────────────────────────────────────────

  const handleLLMResponse = useCallback(
    async (_userText: string) => {
      if (!store.session) return

      store.setThinking(true)
      store.clearStreamText()

      // Create placeholder assistant message
      store.addMessage('assistant', '…')

      await streamAvatarResponse(
        store.personaId,
        store.session.messages.slice(0, -1), // exclude the placeholder
        store.productContext || undefined,
        {
          onTextChunk: (chunk) => {
            store.appendStreamText(chunk)
            store.updateLastAssistantMessage(store.currentStreamText + chunk)
          },
          onEmotionUpdate: (emotion) => {
            applyEmotion(emotion)
          },
          onComplete: (fullText) => {
            store.setThinking(false)
            store.updateLastAssistantMessage(fullText)
            speakResponse(fullText)
          },
          onError: (err) => {
            store.setThinking(false)
            store.setError(err.message)
          },
        }
      )
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [store, applyEmotion]
  )

  // ── TTS + Lip Sync ───────────────────────────────────────────

  const speakResponse = useCallback(
    (text: string) => {
      store.setSpeaking(true)

      // Generate phoneme approximation
      const estimatedDurationMs = (text.split(' ').length / 2.5) * 1000 // ~150 wpm
      const phonemes = audioManagerRef.current.estimatePhonemes(text, estimatedDurationMs)
      setPhonemes(phonemes)

      audioManagerRef.current.speak(
        text,
        { rate: 0.9, pitch: 1.0 },
        undefined,
        () => {
          store.setSpeaking(false)
          store.updateAvatarAnim({ mouthOpenness: 0, isSpeaking: false })
        }
      )
    },
    [store, setPhonemes]
  )

  const interruptSpeech = useCallback(() => {
    audioManagerRef.current.stopSpeaking()
    store.setSpeaking(false)
    store.updateAvatarAnim({ mouthOpenness: 0, isSpeaking: false })
  }, [store])

  // ── Text Input Fallback ──────────────────────────────────────

  const sendTextMessage = useCallback(
    async (text: string) => {
      if (!store.session || !text.trim()) return
      store.addMessage('user', text.trim())
      await handleLLMResponse(text.trim())
    },
    [store, handleLLMResponse]
  )

  return {
    startSession,
    startListening,
    stopListening,
    interruptSpeech,
    sendTextMessage,
    session: store.session,
    isListening: store.isListening,
    isSpeaking: store.isSpeaking,
    isThinking: store.isThinking,
    micLevel: store.micLevel,
    interimTranscript: store.interimTranscript,
    error: store.error,
    messages: store.session?.messages ?? [],
  }
}
