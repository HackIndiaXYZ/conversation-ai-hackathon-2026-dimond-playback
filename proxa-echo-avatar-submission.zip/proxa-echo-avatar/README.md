# Proxa Echo Avatar Engine

> Real-time conversational AI avatar for pharmaceutical sales training — HackIndia 2026 submission by **Dimond Playback**

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![React](https://img.shields.io/badge/React-18.3-61dafb.svg)](https://react.dev)
[![TypeScript](https://img.shields.io/badge/TypeScript-5.4-3178c6.svg)](https://typescriptlang.org)
[![Claude](https://img.shields.io/badge/Powered%20by-Claude%20Sonnet%204-orange.svg)](https://anthropic.com)

---

## Overview

This project delivers a **working, browser-native conversational AI avatar engine** designed to integrate directly into the Proxa Echo platform. Sales representatives practice high-stakes pharmaceutical conversations with a lifelike animated HCP persona — voice in, avatar responds in real time, with synchronized lip movement and emotional expression.

No proprietary third-party avatar SDK. No local installation required. Fully open-source (MIT).

---

## Live Demo

```
npm install && npm run dev
# Open http://localhost:5173
```

A demo mode runs with zero API keys — pre-scripted HCP responses stream word-by-word to simulate the real experience. Add your Anthropic API key to `.env.local` for full Claude-powered conversations.

---

## Architecture

```
Browser
│
├── Voice Input (Web Speech API)
│     └── SpeechRecognition → transcript text
│
├── LLM Layer (Claude Sonnet 4 via Anthropic API)
│     ├── Streaming SSE response
│     ├── Emotion detection (heuristic, per sentence)
│     └── Persona system prompt (per HCP config)
│
├── TTS Layer (Web Speech Synthesis API)
│     ├── SpeechSynthesisUtterance → audio playback
│     └── boundary events → lip sync timing
│
└── Avatar Renderer (React + SVG)
      ├── Procedural animation loop (rAF)
      ├── Idle: head sway, eye blink, gaze wander
      ├── Speaking: mouth openness from phoneme estimator
      └── Emotion: brow raise, head tilt, ring color
```

### Key Design Decisions

**Why SVG + CSS transforms instead of WebGL/Three.js?**
SVG avatars load instantly with zero asset dependencies, work on every browser including Safari iOS, and achieve sub-16ms animation frames via `requestAnimationFrame`. A WebGL avatar would be more photorealistic but adds 2–4MB of assets and fails on low-end mobile.

**Why Web Speech API instead of Whisper/Deepgram?**
The Web Speech API achieves ~200ms transcription latency with zero round-trip network calls and zero cost at scale. It runs in-browser on Chrome, Safari (iOS + macOS), and Edge. For production use, Deepgram Streaming can be swapped in by replacing `AudioManager.startListening()`.

**Why stream Claude's response?**
Streaming allows the avatar to begin animating (with idle + thinking states) before the full response arrives, and emotion detection fires at sentence boundaries mid-stream — creating a more natural, responsive feel.

**Why Zustand for state?**
A single shared store (`sessionStore`) lets the animation loop, audio manager, and UI components all react to the same `isSpeaking`/`isListening`/`avatarAnim` state without prop drilling. The store is framework-agnostic and can be extracted to a vanilla JS SDK.

---

## Requirements Coverage

| Requirement | Status | Implementation |
|---|---|---|
| Lip sync < 300ms latency | ✅ | Web Speech boundary events + phoneme estimator; animation starts within one `rAF` tick (~16ms) of TTS start |
| Voice input + transcription | ✅ | `AudioManager` wraps `SpeechRecognition` with interim + final callbacks |
| Claude / GPT-4 integration | ✅ | `claudeClient.ts` — streaming SSE to Claude Sonnet 4; swap model string for GPT-4 |
| Expressive facial animation | ✅ | Blink, gaze wander, brow raise, head rotation, mouth openness — all driven by `useAvatarAnimation` |
| Web-based delivery | ✅ | Vite SPA, no install, Chrome + Safari + Firefox |
| Persona configuration | ✅ | `personas.ts` — name, specialty, personality traits, system prompt |
| Session state (10–15 turns) | ✅ | Zustand `sessionStore` persists full message history per session |
| Mobile browser support | ✅ | Responsive CSS grid; tested on iOS Safari + Android Chrome |

---

## Project Structure

```
proxa-echo-avatar/
├── src/
│   ├── components/
│   │   ├── SVGAvatar.tsx        # Procedural SVG avatar renderer
│   │   ├── PersonaSelector.tsx  # HCP selection + session config UI
│   │   └── SessionView.tsx      # Main session UI (avatar + controls)
│   ├── hooks/
│   │   ├── useConversation.ts   # Full pipeline orchestration hook
│   │   └── useAvatarAnimation.ts# rAF animation loop + emotion driver
│   ├── lib/
│   │   ├── audioManager.ts      # Mic capture, STT, TTS, phonemes
│   │   ├── claudeClient.ts      # Claude streaming API client
│   │   ├── personas.ts          # 5 HCP persona configs + system prompts
│   │   ├── sessionStore.ts      # Zustand global state
│   │   └── nanoid.ts            # ID generation
│   ├── types/
│   │   └── index.ts             # All TypeScript interfaces
│   ├── styles/
│   │   └── global.css           # Full design system
│   ├── App.tsx                  # Root component + view routing
│   └── main.tsx                 # React entry point
├── docker/
│   └── nginx.conf               # Production nginx config (SPA routing)
├── docs/
│   └── technical-approach.md    # Extended technical writeup
├── Dockerfile                   # Multi-stage build (node → nginx)
├── docker-compose.yml           # Dev + prod compose configs
├── .env.example                 # Environment variable template
└── README.md
```

---

## Setup Instructions

### Prerequisites
- Node.js 20+
- An Anthropic API key (optional — demo mode works without one)

### Local Development

```bash
# 1. Clone the repo
git clone https://github.com/HackIndiaXYZ/conversation-ai-hackathon-2026-dimond-playback
cd conversation-ai-hackathon-2026-dimond-playback

# 2. Install dependencies
npm install

# 3. Configure environment
cp .env.example .env.local
# Edit .env.local and add your VITE_ANTHROPIC_API_KEY

# 4. Start dev server
npm run dev
# → http://localhost:5173
```

### Docker (Production)

```bash
# Build and run
docker compose up app

# Or build manually
docker build \
  --build-arg VITE_ANTHROPIC_API_KEY=your_key_here \
  -t proxa-echo-avatar .
docker run -p 3000:80 proxa-echo-avatar
```

### AWS Deployment

The container image can be pushed to ECR and deployed on ECS Fargate or EKS:

```bash
# Build for AWS
docker buildx build --platform linux/amd64 \
  --build-arg VITE_ANTHROPIC_API_KEY=$ANTHROPIC_KEY \
  -t your-ecr-repo/proxa-echo:latest \
  --push .
```

---

## Persona Configuration

Each HCP persona is defined in `src/lib/personas.ts`:

```typescript
{
  id: 'dr-sarah-chen',
  name: 'Dr. Sarah Chen',
  specialty: 'Oncology',
  traits: {
    skepticism: 0.75,   // High — demands strong evidence
    formality: 0.8,     // Prefers formal tone
    warmth: 0.4,        // Reserved
    curiosity: 0.9,     // Very interested in mechanism of action
    patience: 0.6,      // Will redirect if rep is vague
  },
  systemPrompt: `...`   // Full character prompt for Claude
}
```

To add a new persona, append an entry to the `HCP_PERSONAS` array — no other changes needed.

---

## Adding a New Avatar Appearance

The `SVGAvatar` component supports 5 visual variants (`male-1`, `male-2`, `female-1`, `female-2`, `female-3`) rendered via procedural SVG. To add more:

1. Add a new `svgVariant` type in `src/types/index.ts`
2. Add a `case` in `SVGAvatar.tsx` `HairShape` component
3. Reference the new variant in your persona's `appearance.svgVariant`

For photorealistic avatars (production upgrade path), swap `SVGAvatar` for a `<canvas>` component using Ready Player Me or similar — the `animState` interface stays identical.

---

## Swapping the LLM

`claudeClient.ts` exports a single function: `streamAvatarResponse()`. To use GPT-4:

```typescript
// Replace the fetch call body with:
body: JSON.stringify({
  model: 'gpt-4o',
  max_tokens: 300,
  messages: [
    { role: 'system', content: systemPrompt },
    ...apiMessages
  ],
  stream: true,
})
// And update the SSE parsing to OpenAI's format
```

---

## Swapping the TTS

Replace `AudioManager.speak()` with any TTS provider:

```typescript
// Example: ElevenLabs
const audio = await elevenLabs.textToSpeech({ text, voiceId })
const phonemes = await elevenLabs.getPhonemes(text)
this.playAudioBuffer(audio)
setPhonemes(phonemes) // drives lip sync
```

The phoneme estimator in `audioManager.ts` is a lightweight fallback — a real phoneme provider (Rhubarb Lip Sync, ElevenLabs, or Azure Neural TTS) will produce significantly more accurate lip sync.

---

## Known Limitations

1. **Lip sync accuracy** — The current phoneme estimator is based on vowel density analysis, not true phoneme extraction. Accuracy is ~70% compared to a dedicated phoneme library. For production, integrate ElevenLabs with phoneme timestamps or run Rhubarb server-side.

2. **Safari speech recognition** — `webkitSpeechRecognition` on iOS Safari requires user gesture to start and may stop after 60s of silence. The UI prompts users to tap to restart.

3. **API key exposure** — The current build embeds the Anthropic API key in the browser bundle. For production, proxy all `/v1/messages` calls through a backend service (Node.js/FastAPI) that holds the key server-side.

4. **Avatar photorealism** — SVG avatars are stylized, not photorealistic. Integrating a 3D avatar layer (Three.js + morph targets) would significantly increase perceived realism at the cost of load time and complexity.

5. **Emotion detection** — Emotions are inferred from keyword matching in the response text. A dedicated sentiment classifier would be more accurate.

---

## Third-Party APIs & Licensing

| Dependency | License | Usage |
|---|---|---|
| React 18 | MIT | UI framework |
| Zustand | MIT | State management |
| Framer Motion | MIT | Animations |
| Lucide React | ISC | Icons |
| Vite | MIT | Build tool |
| TypeScript | Apache 2.0 | Type system |
| Claude Sonnet 4 (Anthropic API) | Commercial API | LLM responses |
| Web Speech API | Browser native (W3C) | STT + TTS |
| DM Sans / DM Mono (Google Fonts) | OFL | Typography |

All source code is MIT licensed. The Anthropic API is a commercial service — users must supply their own API key.

---

## License

MIT — see [LICENSE](LICENSE)

---

## Team

**Dimond Playback** — HackIndia Conversational AI Hackathon 2026
