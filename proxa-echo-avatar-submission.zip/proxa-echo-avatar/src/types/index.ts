// ─────────────────────────────────────────────
// Persona Configuration
// ─────────────────────────────────────────────

export type AvatarEmotion = 'neutral' | 'engaged' | 'skeptical' | 'positive' | 'thinking' | 'concerned'

export interface AvatarAppearance {
  id: string
  name: string
  /** Path to avatar sprite sheet or 3D model URL */
  assetUrl: string
  /** Fallback SVG avatar identifier */
  svgVariant: 'male-1' | 'male-2' | 'female-1' | 'female-2' | 'female-3'
  skinTone: string
  hairColor: string
  hairStyle: 'short' | 'medium' | 'long' | 'bun' | 'bald'
  attire: 'whitecoat' | 'business' | 'scrubs'
}

export interface HCPPersona {
  id: string
  name: string
  title: string
  specialty: string
  institution: string
  /** Avatar visual appearance */
  appearance: AvatarAppearance
  /** Personality traits 0–1 scale */
  traits: {
    skepticism: number    // 0 = very open, 1 = very skeptical
    formality: number     // 0 = casual, 1 = very formal
    warmth: number        // 0 = cold, 1 = warm
    curiosity: number     // 0 = dismissive, 1 = highly curious
    patience: number      // 0 = impatient, 1 = very patient
  }
  /** Drug/product context for this session */
  productContext?: string
  /** LLM system prompt (auto-generated from traits if not provided) */
  systemPrompt?: string
}

// ─────────────────────────────────────────────
// Conversation State
// ─────────────────────────────────────────────

export interface ConversationMessage {
  id: string
  role: 'user' | 'assistant'
  content: string
  timestamp: number
  emotion?: AvatarEmotion
  audioUrl?: string
}

export interface SessionState {
  sessionId: string
  personaId: string
  messages: ConversationMessage[]
  isActive: boolean
  startedAt: number
  totalTurns: number
}

// ─────────────────────────────────────────────
// Audio + Lip Sync
// ─────────────────────────────────────────────

export interface PhonemeFrame {
  phoneme: string
  startMs: number
  endMs: number
  amplitude: number
}

export interface LipSyncData {
  frames: PhonemeFrame[]
  totalDurationMs: number
}

export interface AudioChunk {
  data: ArrayBuffer
  sampleRate: number
  channelCount: number
}

// ─────────────────────────────────────────────
// Avatar Animation State
// ─────────────────────────────────────────────

export interface AvatarAnimState {
  emotion: AvatarEmotion
  isSpeaking: boolean
  mouthOpenness: number      // 0–1
  eyeBlink: boolean
  headRotX: number           // degrees: -10 to +10
  headRotY: number           // degrees: -15 to +15
  browRaise: number          // 0–1
  gazeX: number              // -1 to +1 (left to right)
  gazeY: number              // -1 to +1 (up to down)
}

// ─────────────────────────────────────────────
// API Interfaces
// ─────────────────────────────────────────────

export interface StreamChunk {
  type: 'text_delta' | 'audio_delta' | 'emotion_update' | 'done'
  text?: string
  audioData?: string          // base64
  emotion?: AvatarEmotion
}

export interface TTSRequest {
  text: string
  voiceId: string
  speed?: number
  pitch?: number
}

export interface TTSResponse {
  audioBuffer: ArrayBuffer
  durationMs: number
  phonemes?: PhonemeFrame[]
}
